﻿namespace AbcRetail.Models
{
    public class Order
    {
        public int OrderID { get; set; }
        public int CustomerID { get; set; }
        public int ProductID { get; set; }
        public DateTime OrderDate { get; set; } = DateTime.Now;

        // Navigation properties for relationships
        public Customer Customer { get; set; }
        public Product Product { get; set; }
    }
}
